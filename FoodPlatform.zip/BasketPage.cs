﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다

namespace FoodPlatform
{
    public partial class BasketPage : Form
    {
        public BasketPage()
        {
            InitializeComponent();
            label_id.Text = DataManager.id;
            Userdata();
        }

        private void Userdata()
        {
            // 회원의 이름, 잔금, 등급 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();
            MySqlConnection conn3 = dbconn.Connection();

            string name = "select name from user where id = '" + label_id.Text + "'";
            string money = "select money from user where id = '" + label_id.Text + "'";
            string grade = "select grade from user where id = '" + label_id.Text + "'";

            MySqlCommand cmd = new MySqlCommand(name);
            MySqlCommand cmd2 = new MySqlCommand(money);
            MySqlCommand cmd3 = new MySqlCommand(grade);
            cmd.Connection = conn;
            cmd2.Connection = conn2;
            cmd3.Connection = conn3;

            conn.Open();
            conn2.Open();
            conn3.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            MySqlDataReader reader2 = cmd2.ExecuteReader();
            MySqlDataReader reader3 = cmd3.ExecuteReader();
            try
            {
                while (reader.Read() && reader2.Read() && reader3.Read())
                {
                    label_name.Text = (reader.GetString(0) + "님");
                    label_money.Text = (reader2.GetString(0) + "원");
                    label_grade.Text = (reader3.GetString(0));
                }
            }
            catch
            {

            }
            finally
            {
                conn.Close();
                conn2.Close();
                conn3.Close();
            }
        }

        private void button_Basketcheck_Click(object sender, EventArgs e)
        {
            // 장바구니 조회
            string constring = "Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand("select orderlog2.product, orderlog2.count, orderlog2.ymd, orderlog2.TPrice from user inner join orderlog2 on user.id = orderlog2.user where user.id = '" + label_id.Text + "'", conDatabase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDatabase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource dbSouce = new BindingSource();

                dbSouce.DataSource = dbdataset;
                dataGridView1.DataSource = dbSouce;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

        private void button_BasketAllDel_Click(object sender, EventArgs e)
        {
            // 장바구니 내역 전부 삭제
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string logorder = "delete from orderlog2 where user = '" + label_id.Text + "'";
                MySqlCommand command = new MySqlCommand(logorder, conn);
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }

            string constring = "Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand("select orderlog2.product, orderlog2.count, orderlog2.ymd from user inner join orderlog2 on user.id = orderlog2.user where user.id = '" + label_id.Text + "'", conDatabase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDatabase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource dbSouce = new BindingSource();

                dbSouce.DataSource = dbdataset;
                dataGridView1.DataSource = dbSouce;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }

        }
    }
}
