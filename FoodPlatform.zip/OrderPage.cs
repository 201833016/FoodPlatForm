﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다

namespace FoodPlatform
{
    public partial class OrderPage : Form
    {
        public OrderPage()
        {
            InitializeComponent();
            label_id.Text = DataManager.id;
            Userdata();
            shopcombo();
            couponcombo();
        }

        private void Userdata()
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();
            MySqlConnection conn3 = dbconn.Connection();

            string name = "select name from user where id = '" + label_id.Text + "'";
            string money = "select money from user where id = '" + label_id.Text + "'";
            string grade = "select grade from user where id = '" + label_id.Text + "'";

            MySqlCommand cmd = new MySqlCommand(name);
            MySqlCommand cmd2 = new MySqlCommand(money);
            MySqlCommand cmd3 = new MySqlCommand(grade);
            cmd.Connection = conn;
            cmd2.Connection = conn2;
            cmd3.Connection = conn3;

            conn.Open();
            conn2.Open();
            conn3.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            MySqlDataReader reader2 = cmd2.ExecuteReader();
            MySqlDataReader reader3 = cmd3.ExecuteReader();
            try
            {
                while (reader.Read() && reader2.Read() && reader3.Read())
                {
                    label_name.Text = (reader.GetString(0) + "님");
                    label_money.Text = (reader2.GetString(0) + "원");
                    label_grade.Text = (reader3.GetString(0));
                }
            }
            catch
            {

            }
            finally
            {
                conn.Close();
                conn2.Close();
                conn3.Close();
            }
        }

        private void button_Main_Click(object sender, EventArgs e)
        {
            // 뒤로가기
            Main showMain = new Main();
            this.Visible = false;             // 현재 창(Window)를 닫기
            showMain.ShowDialog();
        }

        private void comboBox_shop_SelectedIndexChanged(object sender, EventArgs e)
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = " select foodname from foodmenu where foodmesort ='" + comboBox_shop.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string smenu = myreader.GetString("foodname");
                    comboBox_menu.Items.Add(smenu);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        void shopcombo()
        {
            // 콤보박스에 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select distinct foodmesort from foodmenu";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string sshop = myreader.GetString("foodmesort");
                    comboBox_shop.Items.Add(sshop);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        void couponcombo()
        {
            // 콤보박스에 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select cpname from coupon";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string scpnmae = myreader.GetString("cpname");
                    comboBox_coupon.Items.Add(scpnmae);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox_coupon_SelectedIndexChanged(object sender, EventArgs e)
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = " select discount from coupon where cpname ='" + comboBox_coupon.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string sdis = myreader.GetString("discount");
                    this.textBox1.Text = sdis;
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox_menu_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 메뉴고르면 값 나오게
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='" + comboBox_menu.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string sprice = myreader.GetString("foodprice");
                    this.label_price.Text = sprice;
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_basket_Click(object sender, EventArgs e)
        {
            // 장바구니
            string qwer = Convert.ToString(label_cnt.Text);
            int qwercnt = int.Parse(qwer);

            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string logorder = "insert into orderlog2 values ('" + label_id.Text + "', '"+comboBox_menu.Text+"', now(), "+ qwercnt + ", '"+ comboBox_shop.Text + "')";
                MySqlCommand command = new MySqlCommand(logorder, conn);
                command.ExecuteNonQuery();

                // 주문할 금액
                if (textBox_price.Text == "")
                {
                    int aaaprice = int.Parse(label_price.Text);
                    int aaacnt = int.Parse(label_cnt.Text);

                    int result = aaaprice * aaacnt;
                    textBox_price.Text = Convert.ToString(result);

                    string aaa = Convert.ToString(label_cnt.Text);
                    int menucnt = int.Parse(aaa);
                    menucnt = 1;
                    label_cnt.Text = Convert.ToString(menucnt);

                }
                else
                {
                    int aaaprice = int.Parse(label_price.Text);
                    int aaacnt = int.Parse(label_cnt.Text);

                    int aaaresult = aaaprice * aaacnt;
                    int result = int.Parse(textBox_price.Text) + aaaresult;
                    textBox_price.Text = Convert.ToString(result);

                    string aaa = Convert.ToString(label_cnt.Text);
                    int menucnt = int.Parse(aaa);
                    menucnt = menucnt + 1;
                    label_cnt.Text = Convert.ToString(menucnt);
                }
                MessageBox.Show( comboBox_menu.Text+ "을 "+ label_cnt.Text+"개 장바구니에 넣었습니다.", "Food Order");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_plus_Click(object sender, EventArgs e)
        {
            string aaa = Convert.ToString(label_cnt.Text);
            int menucnt = int.Parse(aaa);
            menucnt = menucnt +  1;
            label_cnt.Text = Convert.ToString(menucnt);
        }

        private void button_minus_Click(object sender, EventArgs e)
        {
            string aaa = Convert.ToString(label_cnt.Text);
            int menucnt = int.Parse(aaa);
            if (menucnt > 0)
            {
                menucnt = menucnt - 1;
                label_cnt.Text = Convert.ToString(menucnt);
            }
            else
            {
                MessageBox.Show("이미 0입니다.", "Food Order");
            }
            
        }

        private void button_order_Click(object sender, EventArgs e)
        {
            // 주문 버튼 클릭시
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();

            int ordercount = int.Parse(label_ordercnt.Text);
            ordercount += 1;

            int mymoney = int.Parse(textBox_money.Text);
            int totalmoney = int.Parse(textBox_price.Text);

            if (mymoney >= totalmoney)
            {
                try
                {
                    // 잔액이 충분 할때
                    conn.Open();
                    conn2.Open();
                    string sql = "update user set ordercount= ordercount + 1 where id='" + label_id.Text + "'";
                    string logorder = "insert into orderlog (user, product, ymd, count, shop) select * from orderlog2 where user='" + label_id.Text + "'";
                    MySqlCommand command = new MySqlCommand(sql, conn);
                    MySqlCommand command2 = new MySqlCommand(logorder, conn2);
                    command.ExecuteNonQuery();
                    command2.ExecuteNonQuery();


                    if (textBox1.Text == "")
                    {
                        string Foodtotalprice = textBox_price.Text;
                        FoodOrder(Foodtotalprice);   // 유저의 돈에서 빼기
                    }
                    else
                    {
                        string Foodtotalprice = textBox_price.Text;
                        int foodtp = int.Parse(Foodtotalprice);
                        string discoint = Convert.ToString(textBox1.Text);
                        int discnt = int.Parse(discoint);

                        int fooddis = foodtp - discnt;
                        string fooddiscount = Convert.ToString(fooddis);

                        FoodOrder(fooddiscount);   // 유저의 돈에서 빼기
                    }

                    ResetOrdermenu();            // 장바구니 update로 초기화

                    UserMoney();
                    Usergrade();
                    Rankup();
  
                    MessageBox.Show("주문 되었습니다.", "Food Order");
                    textBox_price.Text = "";

                }
                catch (Exception)
                {

                }
                finally
                {
                    conn.Close();
                    conn2.Close();
                }
            }
            else
            {
                ResetOrdermenu();            // 장바구니 update로 초기화
                UserMoney();
                Usergrade();
                Rankup();
                MessageBox.Show("잔액이 부족하여 취소 되었습니다.");
                textBox_price.Text = "";
            }
        }

        private void FoodOrder(string Foodtotalprice)
        {
            // 사용자가 구매한 값

            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                
                string sql = "update user set money = money- " + Foodtotalprice + " Where id = '" + label_id.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void UserMoney()
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            string money = "select money from user where id = '" + label_id.Text + "'";
            MySqlCommand cmd = new MySqlCommand(money);
            cmd.Connection = conn;
            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    textBox_money.Text = (reader.GetString(0));
                }
            }
            catch
            {
                conn.Close();
            }
        }

        private void OrderPage_Load(object sender, EventArgs e)
        {
            textBox_price.Text = "";
            UserMoney();
            Usergrade();
            Rankup();
        }

        private void Usergrade()
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();

            string ordercnt = "select ordercount from user where id = '" + label_id.Text + "'";
            string grade = "select grade from user where id = '" + label_id.Text + "'";

            MySqlCommand cmd = new MySqlCommand(ordercnt);
            MySqlCommand cmd2 = new MySqlCommand(grade);
            cmd.Connection = conn;
            cmd2.Connection = conn2;

            conn.Open();
            conn2.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            MySqlDataReader reader2 = cmd2.ExecuteReader();
            try
            {
                while (reader.Read() && reader2.Read())
                {
                    label_ordercnt.Text = (reader.GetString(0));
                    label_grade.Text = (reader2.GetString(0));
                }
            }
            catch
            {

            }
            finally
            {
                conn.Close();
                conn2.Close();
            }
        }

        private void Rankup()
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();

            int ordercount = int.Parse(label_ordercnt.Text);
            if (ordercount == 3)
            {
                // 3번이상 시키면 실버급
                try
                {
                    conn.Open();
                    string sql = "update user set grade = '실버' where id='" + label_id.Text + "'";
                    MySqlCommand command = new MySqlCommand(sql, conn);
                    command.ExecuteNonQuery();
                    Usergrade();

                }
                catch
                {

                }
                finally
                {
                    conn.Close();
                }
            }
            else if (ordercount == 5)
            {
                // 5번이상 시키면 골드급
                try
                {
                    conn.Open();
                    string sql = "update user set grade = '골드' where id='" + label_id.Text + "'";
                    MySqlCommand command = new MySqlCommand(sql, conn);
                    command.ExecuteNonQuery();
                    Usergrade();

                }
                catch
                {

                }
                finally
                {
                    conn.Close();
                }
            }
            else if (ordercount == 7)
            {
                // 7번이상 시키면 플래티넘급
                try
                {
                    conn.Open();
                    string sql = "update user set grade = '플래티넘' where id='" + label_id.Text + "'";
                    MySqlCommand command = new MySqlCommand(sql, conn);
                    command.ExecuteNonQuery();
                    Usergrade();

                }
                catch
                {

                }
                finally
                {
                    conn.Close();
                }
            }

        }

        private void ResetOrdermenu()
        {
            // 장바구니 update로 초기화
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string logorder = "delete from orderlog2 where user = '" + label_id.Text + "'";
                MySqlCommand command = new MySqlCommand(logorder, conn);
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        
    }
}
