﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다

namespace FoodPlatform
{
    public partial class CeoAdjust : Form
    {
        public CeoAdjust()
        {
            InitializeComponent();
            label_id.Text = DataManager.id;
            CeoData();
            MenuPriceFix();
            MenuDelete();
        }
        private void CeoData()
        {
            // 로그인 한 CEO 데이터
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();
            MySqlConnection conn3 = dbconn.Connection();

            string name = "select ceoname from ceo where ceoid = '" + label_id.Text + "'";
            string shop = "select ceoshop from ceo where ceoid = '" + label_id.Text + "'";

            MySqlCommand cmd = new MySqlCommand(name);
            MySqlCommand cmd2 = new MySqlCommand(shop);

            cmd.Connection = conn;
            cmd2.Connection = conn2;

            conn.Open();
            conn2.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            MySqlDataReader reader2 = cmd2.ExecuteReader();
            try
            {
                while (reader.Read() && reader2.Read())
                {
                    label_name.Text = (reader.GetString(0) + "님");
                    label_shopname.Text = (reader2.GetString(0));
                }
            }
            catch
            {

            }
            finally
            {
                conn.Close();
                conn2.Close();
            }
        }

        void MenuPriceFix()
        {
            // 가격 수정 콤보박스
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodmesort = '"+ label_shopname .Text+ "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                comboBox_MPF.Items.Clear();
                while (myreader.Read())
                {
                    string smenu = myreader.GetString("foodname");

                    comboBox_MPF.Items.Add(smenu);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox_MPF_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='" + comboBox_MPF.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                

                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    string sprice = myreader.GetString("foodprice");
                    this.textBox_MFTrace.Text = sname;
                    this.textBox_MFprice.Text = sprice;

                    
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_Mfix_Click(object sender, EventArgs e)
        {
            // 가격 수정
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "update foodmenu set foodprice = '" + textBox_MFprice.Text + "' where foodname = '" + textBox_MFTrace.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_MFTrace.Text + "가격을 수정하였습니다.");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            reload();
        }

        private void button_Madd_Click(object sender, EventArgs e)
        {
            // 메뉴 추가 버튼 클릭시
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "insert into foodmenu values('" + textBox_MAname.Text + "', " + textBox_MAprice.Text + ", '"+ label_shopname.Text + "')";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_MAname.Text + "메뉴를 추가하였습니다.");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            reload();
        }

        void MenuDelete()
        {
            // 메뉴 삭제 콤보박스
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodmesort = '" + label_shopname.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                comboBox_MD.Items.Clear();
                while (myreader.Read())
                {
                    string smenu = myreader.GetString("foodname");

                    comboBox_MD.Items.Add(smenu);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox_MD_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='" + comboBox_MD.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                
                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    this.textBox_MDTrace.Text = sname;

                    
                    
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
         
        }

        private void button_Mdelete_Click(object sender, EventArgs e)
        {
            // 메뉴 삭제 버튼 클릭시
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "delete from foodmenu where foodname = '"+textBox_MDTrace.Text+"'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_MDTrace.Text + "메뉴를 삭제하였습니다.");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            reload();
        }

        private void CeoAdjust_Load(object sender, EventArgs e)
        {
            
        }

        void reload()
        {
            // 다음 행동을 위한 빈칸으로 처리
            MenuPriceFix();
            MenuDelete();
            textBox_MAname.Text = "";
            textBox_MAprice.Text = "";
            comboBox_MPF.Text = "";
            textBox_MFTrace.Text = "";
            textBox_MFprice.Text = "";
            comboBox_MD.Text = "";
            textBox_MDTrace.Text = "";
        }

        private void button_out_Click(object sender, EventArgs e)
        {
            // 로그아웃 버튼
            Login showlogin = new Login();
            this.Visible = false;             // 현재 창(Window)를 닫기
            showlogin.ShowDialog();
        }
    }
}
