﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodPlatform
{
    public class DataManager
    {
        public static string id;
        public static string name;
    }
}
