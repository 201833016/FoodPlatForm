﻿namespace FoodPlatform
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.check_time = new System.Windows.Forms.CheckBox();
            this.check_shop = new System.Windows.Forms.CheckBox();
            this.check_product = new System.Windows.Forms.CheckBox();
            this.button_check = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.comboBox_user = new System.Windows.Forms.ComboBox();
            this.button_out = new System.Windows.Forms.Button();
            this.comboBox_MenuCombo = new System.Windows.Forms.ComboBox();
            this.button_Mfix = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_MenuPriceFix = new System.Windows.Forms.TextBox();
            this.textBox_MenuCB = new System.Windows.Forms.TextBox();
            this.button_MenuAdd = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_MenuAddPrice = new System.Windows.Forms.TextBox();
            this.textBox_MenuAdd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox_Menucombo2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_MenuDelete = new System.Windows.Forms.TextBox();
            this.button_Mdelete = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_shop1 = new System.Windows.Forms.ComboBox();
            this.comboBox_shop2 = new System.Windows.Forms.ComboBox();
            this.comboBox_shop3 = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(764, 414);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox_shop3);
            this.tabPage1.Controls.Add(this.comboBox_shop2);
            this.tabPage1.Controls.Add(this.comboBox_shop1);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.comboBox_Menucombo2);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textBox_MenuDelete);
            this.tabPage1.Controls.Add(this.button_Mdelete);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBox_MenuAdd);
            this.tabPage1.Controls.Add(this.button_MenuAdd);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBox_MenuAddPrice);
            this.tabPage1.Controls.Add(this.button_Mfix);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox_MenuPriceFix);
            this.tabPage1.Controls.Add(this.textBox_MenuCB);
            this.tabPage1.Controls.Add(this.comboBox_MenuCombo);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(756, 382);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "메뉴 조정";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.check_time);
            this.tabPage4.Controls.Add(this.check_shop);
            this.tabPage4.Controls.Add(this.check_product);
            this.tabPage4.Controls.Add(this.button_check);
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Controls.Add(this.comboBox_user);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(756, 382);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "주문 검색";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // check_time
            // 
            this.check_time.AutoSize = true;
            this.check_time.Location = new System.Drawing.Point(396, 24);
            this.check_time.Name = "check_time";
            this.check_time.Size = new System.Drawing.Size(106, 22);
            this.check_time.TabIndex = 8;
            this.check_time.Text = "주문시간";
            this.check_time.UseVisualStyleBackColor = true;
            // 
            // check_shop
            // 
            this.check_shop.AutoSize = true;
            this.check_shop.Location = new System.Drawing.Point(306, 24);
            this.check_shop.Name = "check_shop";
            this.check_shop.Size = new System.Drawing.Size(70, 22);
            this.check_shop.TabIndex = 7;
            this.check_shop.Text = "가게";
            this.check_shop.UseVisualStyleBackColor = true;
            // 
            // check_product
            // 
            this.check_product.AutoSize = true;
            this.check_product.Location = new System.Drawing.Point(194, 24);
            this.check_product.Name = "check_product";
            this.check_product.Size = new System.Drawing.Size(88, 22);
            this.check_product.TabIndex = 6;
            this.check_product.Text = "제품명";
            this.check_product.UseVisualStyleBackColor = true;
            // 
            // button_check
            // 
            this.button_check.Location = new System.Drawing.Point(587, 275);
            this.button_check.Name = "button_check";
            this.button_check.Size = new System.Drawing.Size(132, 65);
            this.button_check.TabIndex = 5;
            this.button_check.Text = "조회";
            this.button_check.UseVisualStyleBackColor = true;
            this.button_check.Click += new System.EventHandler(this.button_check_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 77);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 30;
            this.dataGridView2.Size = new System.Drawing.Size(564, 263);
            this.dataGridView2.TabIndex = 4;
            // 
            // comboBox_user
            // 
            this.comboBox_user.FormattingEnabled = true;
            this.comboBox_user.Location = new System.Drawing.Point(22, 22);
            this.comboBox_user.Name = "comboBox_user";
            this.comboBox_user.Size = new System.Drawing.Size(121, 26);
            this.comboBox_user.TabIndex = 3;
            // 
            // button_out
            // 
            this.button_out.Location = new System.Drawing.Point(683, 3);
            this.button_out.Name = "button_out";
            this.button_out.Size = new System.Drawing.Size(105, 39);
            this.button_out.TabIndex = 1;
            this.button_out.Text = "로그아웃";
            this.button_out.UseVisualStyleBackColor = true;
            this.button_out.Click += new System.EventHandler(this.button_out_Click);
            // 
            // comboBox_MenuCombo
            // 
            this.comboBox_MenuCombo.FormattingEnabled = true;
            this.comboBox_MenuCombo.Location = new System.Drawing.Point(120, 131);
            this.comboBox_MenuCombo.Name = "comboBox_MenuCombo";
            this.comboBox_MenuCombo.Size = new System.Drawing.Size(121, 26);
            this.comboBox_MenuCombo.TabIndex = 0;
            this.comboBox_MenuCombo.SelectedIndexChanged += new System.EventHandler(this.comboBox_MenuCombo_SelectedIndexChanged);
            // 
            // button_Mfix
            // 
            this.button_Mfix.Location = new System.Drawing.Point(120, 287);
            this.button_Mfix.Name = "button_Mfix";
            this.button_Mfix.Size = new System.Drawing.Size(121, 41);
            this.button_Mfix.TabIndex = 23;
            this.button_Mfix.Text = "수정";
            this.button_Mfix.UseVisualStyleBackColor = true;
            this.button_Mfix.Click += new System.EventHandler(this.button_Mfix_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "가격";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 21;
            this.label1.Text = "상품이름";
            // 
            // textBox_MenuPriceFix
            // 
            this.textBox_MenuPriceFix.Location = new System.Drawing.Point(120, 237);
            this.textBox_MenuPriceFix.Name = "textBox_MenuPriceFix";
            this.textBox_MenuPriceFix.Size = new System.Drawing.Size(121, 28);
            this.textBox_MenuPriceFix.TabIndex = 20;
            // 
            // textBox_MenuCB
            // 
            this.textBox_MenuCB.Location = new System.Drawing.Point(120, 183);
            this.textBox_MenuCB.Name = "textBox_MenuCB";
            this.textBox_MenuCB.ReadOnly = true;
            this.textBox_MenuCB.Size = new System.Drawing.Size(121, 28);
            this.textBox_MenuCB.TabIndex = 19;
            // 
            // button_MenuAdd
            // 
            this.button_MenuAdd.Location = new System.Drawing.Point(364, 281);
            this.button_MenuAdd.Name = "button_MenuAdd";
            this.button_MenuAdd.Size = new System.Drawing.Size(121, 41);
            this.button_MenuAdd.TabIndex = 26;
            this.button_MenuAdd.Text = "메뉴추가";
            this.button_MenuAdd.UseVisualStyleBackColor = true;
            this.button_MenuAdd.Click += new System.EventHandler(this.button_MenuAdd_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(306, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 25;
            this.label3.Text = "가격";
            // 
            // textBox_MenuAddPrice
            // 
            this.textBox_MenuAddPrice.Location = new System.Drawing.Point(364, 231);
            this.textBox_MenuAddPrice.Name = "textBox_MenuAddPrice";
            this.textBox_MenuAddPrice.Size = new System.Drawing.Size(121, 28);
            this.textBox_MenuAddPrice.TabIndex = 24;
            // 
            // textBox_MenuAdd
            // 
            this.textBox_MenuAdd.Location = new System.Drawing.Point(364, 180);
            this.textBox_MenuAdd.Name = "textBox_MenuAdd";
            this.textBox_MenuAdd.Size = new System.Drawing.Size(121, 28);
            this.textBox_MenuAdd.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 28;
            this.label4.Text = "상품이름";
            // 
            // comboBox_Menucombo2
            // 
            this.comboBox_Menucombo2.FormattingEnabled = true;
            this.comboBox_Menucombo2.Location = new System.Drawing.Point(585, 166);
            this.comboBox_Menucombo2.Name = "comboBox_Menucombo2";
            this.comboBox_Menucombo2.Size = new System.Drawing.Size(140, 26);
            this.comboBox_Menucombo2.TabIndex = 32;
            this.comboBox_Menucombo2.SelectedIndexChanged += new System.EventHandler(this.comboBox_Menucombo2_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(499, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 31;
            this.label5.Text = "상품이름";
            // 
            // textBox_MenuDelete
            // 
            this.textBox_MenuDelete.Location = new System.Drawing.Point(585, 221);
            this.textBox_MenuDelete.Name = "textBox_MenuDelete";
            this.textBox_MenuDelete.ReadOnly = true;
            this.textBox_MenuDelete.Size = new System.Drawing.Size(140, 28);
            this.textBox_MenuDelete.TabIndex = 30;
            // 
            // button_Mdelete
            // 
            this.button_Mdelete.Location = new System.Drawing.Point(602, 289);
            this.button_Mdelete.Name = "button_Mdelete";
            this.button_Mdelete.Size = new System.Drawing.Size(123, 41);
            this.button_Mdelete.TabIndex = 29;
            this.button_Mdelete.Text = "메뉴 삭제";
            this.button_Mdelete.UseVisualStyleBackColor = true;
            this.button_Mdelete.Click += new System.EventHandler(this.button_Mdelete_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(100, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 18);
            this.label6.TabIndex = 33;
            this.label6.Text = "메뉴 수정";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(371, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 18);
            this.label7.TabIndex = 34;
            this.label7.Text = "메뉴 추가";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(623, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 18);
            this.label8.TabIndex = 35;
            this.label8.Text = "메뉴 삭제";
            // 
            // comboBox_shop1
            // 
            this.comboBox_shop1.FormattingEnabled = true;
            this.comboBox_shop1.Location = new System.Drawing.Point(120, 71);
            this.comboBox_shop1.Name = "comboBox_shop1";
            this.comboBox_shop1.Size = new System.Drawing.Size(121, 26);
            this.comboBox_shop1.TabIndex = 36;
            this.comboBox_shop1.SelectedIndexChanged += new System.EventHandler(this.comboBox_shop1_SelectedIndexChanged);
            // 
            // comboBox_shop2
            // 
            this.comboBox_shop2.FormattingEnabled = true;
            this.comboBox_shop2.Location = new System.Drawing.Point(364, 71);
            this.comboBox_shop2.Name = "comboBox_shop2";
            this.comboBox_shop2.Size = new System.Drawing.Size(121, 26);
            this.comboBox_shop2.TabIndex = 37;
            // 
            // comboBox_shop3
            // 
            this.comboBox_shop3.FormattingEnabled = true;
            this.comboBox_shop3.Location = new System.Drawing.Point(604, 71);
            this.comboBox_shop3.Name = "comboBox_shop3";
            this.comboBox_shop3.Size = new System.Drawing.Size(121, 26);
            this.comboBox_shop3.TabIndex = 38;
            this.comboBox_shop3.SelectedIndexChanged += new System.EventHandler(this.comboBox_shop3_SelectedIndexChanged);
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_out);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminPage";
            this.Text = "AdminPage";
            this.Load += new System.EventHandler(this.AdminPage_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox comboBox_user;
        private System.Windows.Forms.Button button_check;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.CheckBox check_time;
        private System.Windows.Forms.CheckBox check_shop;
        private System.Windows.Forms.CheckBox check_product;
        private System.Windows.Forms.Button button_out;
        private System.Windows.Forms.ComboBox comboBox_MenuCombo;
        private System.Windows.Forms.Button button_Mfix;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_MenuPriceFix;
        private System.Windows.Forms.TextBox textBox_MenuCB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_MenuAdd;
        private System.Windows.Forms.Button button_MenuAdd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_MenuAddPrice;
        private System.Windows.Forms.ComboBox comboBox_Menucombo2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_MenuDelete;
        private System.Windows.Forms.Button button_Mdelete;
        private System.Windows.Forms.ComboBox comboBox_shop3;
        private System.Windows.Forms.ComboBox comboBox_shop2;
        private System.Windows.Forms.ComboBox comboBox_shop1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}