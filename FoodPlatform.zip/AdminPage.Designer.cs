﻿namespace FoodPlatform
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_menu = new System.Windows.Forms.ComboBox();
            this.button_fix = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_chickenprice = new System.Windows.Forms.TextBox();
            this.textBox_chicken = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboBox_menu2 = new System.Windows.Forms.ComboBox();
            this.button_fix2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_coffeeprice = new System.Windows.Forms.TextBox();
            this.textBox_coffee = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(764, 426);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox_menu);
            this.tabPage1.Controls.Add(this.button_fix);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox_chickenprice);
            this.tabPage1.Controls.Add(this.textBox_chicken);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(756, 394);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "치킨";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_menu
            // 
            this.comboBox_menu.FormattingEnabled = true;
            this.comboBox_menu.Location = new System.Drawing.Point(315, 83);
            this.comboBox_menu.Name = "comboBox_menu";
            this.comboBox_menu.Size = new System.Drawing.Size(140, 26);
            this.comboBox_menu.TabIndex = 7;
            this.comboBox_menu.SelectedIndexChanged += new System.EventHandler(this.comboBox_menu_SelectedIndexChanged);
            // 
            // button_fix
            // 
            this.button_fix.Location = new System.Drawing.Point(456, 264);
            this.button_fix.Name = "button_fix";
            this.button_fix.Size = new System.Drawing.Size(108, 41);
            this.button_fix.TabIndex = 5;
            this.button_fix.Text = "수정";
            this.button_fix.UseVisualStyleBackColor = true;
            this.button_fix.Click += new System.EventHandler(this.button_fix_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(160, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "가격";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(138, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "상품이름";
            // 
            // textBox_chickenprice
            // 
            this.textBox_chickenprice.Location = new System.Drawing.Point(252, 194);
            this.textBox_chickenprice.Name = "textBox_chickenprice";
            this.textBox_chickenprice.Size = new System.Drawing.Size(254, 28);
            this.textBox_chickenprice.TabIndex = 1;
            // 
            // textBox_chicken
            // 
            this.textBox_chicken.Location = new System.Drawing.Point(252, 140);
            this.textBox_chicken.Name = "textBox_chicken";
            this.textBox_chicken.ReadOnly = true;
            this.textBox_chicken.Size = new System.Drawing.Size(254, 28);
            this.textBox_chicken.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.comboBox_menu2);
            this.tabPage2.Controls.Add(this.button_fix2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.textBox_coffeeprice);
            this.tabPage2.Controls.Add(this.textBox_coffee);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(756, 394);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "커피";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBox_menu2
            // 
            this.comboBox_menu2.FormattingEnabled = true;
            this.comboBox_menu2.Location = new System.Drawing.Point(249, 64);
            this.comboBox_menu2.Name = "comboBox_menu2";
            this.comboBox_menu2.Size = new System.Drawing.Size(226, 26);
            this.comboBox_menu2.TabIndex = 12;
            this.comboBox_menu2.SelectedIndexChanged += new System.EventHandler(this.comboBox_menu2_SelectedIndexChanged);
            // 
            // button_fix2
            // 
            this.button_fix2.Location = new System.Drawing.Point(453, 271);
            this.button_fix2.Name = "button_fix2";
            this.button_fix2.Size = new System.Drawing.Size(108, 41);
            this.button_fix2.TabIndex = 11;
            this.button_fix2.Text = "수정";
            this.button_fix2.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(157, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 10;
            this.label3.Text = "가격";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(135, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "상품이름";
            // 
            // textBox_coffeeprice
            // 
            this.textBox_coffeeprice.Location = new System.Drawing.Point(249, 201);
            this.textBox_coffeeprice.Name = "textBox_coffeeprice";
            this.textBox_coffeeprice.Size = new System.Drawing.Size(254, 28);
            this.textBox_coffeeprice.TabIndex = 8;
            // 
            // textBox_coffee
            // 
            this.textBox_coffee.Location = new System.Drawing.Point(249, 147);
            this.textBox_coffee.Name = "textBox_coffee";
            this.textBox_coffee.ReadOnly = true;
            this.textBox_coffee.Size = new System.Drawing.Size(254, 28);
            this.textBox_coffee.TabIndex = 7;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(756, 394);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "주문내역";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(29, 289);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "주문내역";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(160, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(593, 388);
            this.dataGridView1.TabIndex = 0;
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminPage";
            this.Text = "AdminPage";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button_fix;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_chickenprice;
        private System.Windows.Forms.TextBox textBox_chicken;
        private System.Windows.Forms.ComboBox comboBox_menu2;
        private System.Windows.Forms.Button button_fix2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_coffeeprice;
        private System.Windows.Forms.TextBox textBox_coffee;
        private System.Windows.Forms.ComboBox comboBox_menu;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
    }
}