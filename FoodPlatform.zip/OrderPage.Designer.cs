﻿namespace FoodPlatform
{
    partial class OrderPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_grade = new System.Windows.Forms.Label();
            this.label_id = new System.Windows.Forms.Label();
            this.label_money = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.button_Main = new System.Windows.Forms.Button();
            this.comboBox_shop = new System.Windows.Forms.ComboBox();
            this.comboBox_menu = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button_basket = new System.Windows.Forms.Button();
            this.button_order = new System.Windows.Forms.Button();
            this.comboBox_coupon = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox_price = new System.Windows.Forms.TextBox();
            this.label_cnt = new System.Windows.Forms.Label();
            this.label_price = new System.Windows.Forms.Label();
            this.button_minus = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.textBox_money = new System.Windows.Forms.TextBox();
            this.label_ordercnt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_grade
            // 
            this.label_grade.AutoSize = true;
            this.label_grade.Location = new System.Drawing.Point(548, 23);
            this.label_grade.Name = "label_grade";
            this.label_grade.Size = new System.Drawing.Size(44, 18);
            this.label_grade.TabIndex = 8;
            this.label_grade.Text = "등급";
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Location = new System.Drawing.Point(441, 23);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(62, 18);
            this.label_id.TabIndex = 7;
            this.label_id.Text = "아이디";
            this.label_id.Visible = false;
            // 
            // label_money
            // 
            this.label_money.AutoSize = true;
            this.label_money.Location = new System.Drawing.Point(724, 23);
            this.label_money.Name = "label_money";
            this.label_money.Size = new System.Drawing.Size(44, 18);
            this.label_money.TabIndex = 6;
            this.label_money.Text = "잔금";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(628, 23);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(44, 18);
            this.label_name.TabIndex = 5;
            this.label_name.Text = "이름";
            // 
            // button_Main
            // 
            this.button_Main.Location = new System.Drawing.Point(26, 23);
            this.button_Main.Name = "button_Main";
            this.button_Main.Size = new System.Drawing.Size(88, 35);
            this.button_Main.TabIndex = 25;
            this.button_Main.Text = "뒤로가기";
            this.button_Main.UseVisualStyleBackColor = true;
            this.button_Main.Click += new System.EventHandler(this.button_Main_Click);
            // 
            // comboBox_shop
            // 
            this.comboBox_shop.FormattingEnabled = true;
            this.comboBox_shop.Location = new System.Drawing.Point(87, 79);
            this.comboBox_shop.Name = "comboBox_shop";
            this.comboBox_shop.Size = new System.Drawing.Size(153, 26);
            this.comboBox_shop.TabIndex = 26;
            this.comboBox_shop.SelectedIndexChanged += new System.EventHandler(this.comboBox_shop_SelectedIndexChanged);
            // 
            // comboBox_menu
            // 
            this.comboBox_menu.FormattingEnabled = true;
            this.comboBox_menu.Location = new System.Drawing.Point(87, 152);
            this.comboBox_menu.Name = "comboBox_menu";
            this.comboBox_menu.Size = new System.Drawing.Size(153, 26);
            this.comboBox_menu.TabIndex = 27;
            this.comboBox_menu.SelectedIndexChanged += new System.EventHandler(this.comboBox_menu_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 29;
            this.label1.Text = "가게";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 30;
            this.label2.Text = "메뉴";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 245);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 31;
            this.label3.Text = "개수";
            // 
            // button_basket
            // 
            this.button_basket.Location = new System.Drawing.Point(99, 324);
            this.button_basket.Name = "button_basket";
            this.button_basket.Size = new System.Drawing.Size(122, 68);
            this.button_basket.TabIndex = 32;
            this.button_basket.Text = "장바구니";
            this.button_basket.UseVisualStyleBackColor = true;
            this.button_basket.Click += new System.EventHandler(this.button_basket_Click);
            // 
            // button_order
            // 
            this.button_order.Location = new System.Drawing.Point(536, 340);
            this.button_order.Name = "button_order";
            this.button_order.Size = new System.Drawing.Size(122, 68);
            this.button_order.TabIndex = 33;
            this.button_order.Text = "주문";
            this.button_order.UseVisualStyleBackColor = true;
            this.button_order.Click += new System.EventHandler(this.button_order_Click);
            // 
            // comboBox_coupon
            // 
            this.comboBox_coupon.FormattingEnabled = true;
            this.comboBox_coupon.Location = new System.Drawing.Point(408, 86);
            this.comboBox_coupon.Name = "comboBox_coupon";
            this.comboBox_coupon.Size = new System.Drawing.Size(121, 26);
            this.comboBox_coupon.TabIndex = 34;
            this.comboBox_coupon.SelectedIndexChanged += new System.EventHandler(this.comboBox_coupon_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(408, 145);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(130, 28);
            this.textBox1.TabIndex = 35;
            // 
            // textBox_price
            // 
            this.textBox_price.Location = new System.Drawing.Point(513, 272);
            this.textBox_price.Name = "textBox_price";
            this.textBox_price.Size = new System.Drawing.Size(189, 28);
            this.textBox_price.TabIndex = 36;
            // 
            // label_cnt
            // 
            this.label_cnt.AutoSize = true;
            this.label_cnt.Location = new System.Drawing.Point(153, 245);
            this.label_cnt.Name = "label_cnt";
            this.label_cnt.Size = new System.Drawing.Size(18, 18);
            this.label_cnt.TabIndex = 38;
            this.label_cnt.Text = "0";
            // 
            // label_price
            // 
            this.label_price.AutoSize = true;
            this.label_price.Location = new System.Drawing.Point(298, 365);
            this.label_price.Name = "label_price";
            this.label_price.Size = new System.Drawing.Size(108, 18);
            this.label_price.TabIndex = 39;
            this.label_price.Text = "메뉴1개가격";
            // 
            // button_minus
            // 
            this.button_minus.Location = new System.Drawing.Point(108, 237);
            this.button_minus.Name = "button_minus";
            this.button_minus.Size = new System.Drawing.Size(39, 35);
            this.button_minus.TabIndex = 40;
            this.button_minus.Text = "-";
            this.button_minus.UseVisualStyleBackColor = true;
            this.button_minus.Click += new System.EventHandler(this.button_minus_Click);
            // 
            // button_plus
            // 
            this.button_plus.Location = new System.Drawing.Point(177, 237);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(39, 35);
            this.button_plus.TabIndex = 41;
            this.button_plus.Text = "+";
            this.button_plus.UseVisualStyleBackColor = true;
            this.button_plus.Click += new System.EventHandler(this.button_plus_Click);
            // 
            // textBox_money
            // 
            this.textBox_money.Location = new System.Drawing.Point(509, 218);
            this.textBox_money.Name = "textBox_money";
            this.textBox_money.ReadOnly = true;
            this.textBox_money.Size = new System.Drawing.Size(193, 28);
            this.textBox_money.TabIndex = 42;
            // 
            // label_ordercnt
            // 
            this.label_ordercnt.AutoSize = true;
            this.label_ordercnt.Location = new System.Drawing.Point(317, 23);
            this.label_ordercnt.Name = "label_ordercnt";
            this.label_ordercnt.Size = new System.Drawing.Size(80, 18);
            this.label_ordercnt.TabIndex = 43;
            this.label_ordercnt.Text = "주문횟수";
            this.label_ordercnt.Visible = false;
            // 
            // OrderPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_ordercnt);
            this.Controls.Add(this.textBox_money);
            this.Controls.Add(this.button_plus);
            this.Controls.Add(this.button_minus);
            this.Controls.Add(this.label_price);
            this.Controls.Add(this.label_cnt);
            this.Controls.Add(this.textBox_price);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.comboBox_coupon);
            this.Controls.Add(this.button_order);
            this.Controls.Add(this.button_basket);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_menu);
            this.Controls.Add(this.comboBox_shop);
            this.Controls.Add(this.button_Main);
            this.Controls.Add(this.label_grade);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.label_money);
            this.Controls.Add(this.label_name);
            this.Name = "OrderPage";
            this.Text = "OrderPage";
            this.Load += new System.EventHandler(this.OrderPage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_grade;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.Label label_money;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button button_Main;
        private System.Windows.Forms.ComboBox comboBox_shop;
        private System.Windows.Forms.ComboBox comboBox_menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_basket;
        private System.Windows.Forms.Button button_order;
        private System.Windows.Forms.ComboBox comboBox_coupon;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox_price;
        private System.Windows.Forms.Label label_cnt;
        private System.Windows.Forms.Label label_price;
        private System.Windows.Forms.Button button_minus;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.TextBox textBox_money;
        private System.Windows.Forms.Label label_ordercnt;
    }
}