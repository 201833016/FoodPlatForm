﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다

namespace FoodPlatform
{
    public partial class Join : Form
    {
        // MySqlConnection connection = new MySqlConnection("Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234;");
        // string Conn = "Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234;";
        // 서버 정보

        public Join()
        {
            InitializeComponent();
        }


        private void button_Join_Click(object sender, EventArgs e)
        {
            
        }

        private void button_out_Click(object sender, EventArgs e)
        {
            // 로그인 화면 버튼
            Login showlogin = new Login();
            this.Visible = false;             // 현재 창(Window)를 닫기
            showlogin.ShowDialog();
        }

        private void button_Join_Click_1(object sender, EventArgs e)
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();

            string JoinIdText = textBox_ID.Text;
            string JoinPasswdText = textBox_Passwd.Text;
            string JoinNameText = textBox_name.Text;
            // 아이디, 비밀번호, 사용자 이름, 전화번호

            if (JoinIdText.Trim() == "")
            {
                MessageBox.Show("아이디를 입력하십시오.");
            }
            else if (JoinPasswdText.Trim() == "")
            {
                MessageBox.Show("비밀번호를 입력하십시오.");
            }
            else if (JoinNameText.Trim() == "")
            {
                MessageBox.Show("이름를 입력하십시오.");
            }

            else
            {
                // 회원가입의 조건 만족시
                conn.Open();

                string sql = "insert into user(id, password, name) values('" + JoinIdText + "', '" + JoinPasswdText + "', '" + JoinNameText + "')";
                try
                {
                    MySqlCommand command = new MySqlCommand(sql, conn);
                    command.ExecuteNonQuery();
                    MessageBox.Show("회원가입 되었습니다.");

                    Login showLogin = new Login();
                    this.Visible = false;             // 현재 창(Window)를 닫기
                    showLogin.ShowDialog();

                }
                catch (Exception)
                {
                    MessageBox.Show("이미 존재하는 아이디입니다.");
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void button_CeoJoin_Click(object sender, EventArgs e)
        {
            // CEO 회원가입 버튼 클릭시
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();

            string CEOID = textBox_CeoID.Text;
            string CEOName = textBox_CeoName.Text;
            string CEOShop = textBox_CeoShop.Text;
            // 아이디, 비밀번호, 사용자 이름, 전화번호

            if (CEOID.Trim() == "")
            {
                MessageBox.Show("아이디를 입력하십시오.");
            }
            else if (CEOShop.Trim() == "")
            {
                MessageBox.Show("종목을 입력하십시오.");
            }
            else if (CEOName.Trim() == "")
            {
                MessageBox.Show("이름를 입력하십시오.");
            }

            else
            {
                try
                {
                    // 종목이 겹치는지 확인
                    conn.Open();
                    string selectshop = "select ceoshop from ceo where ceoshop = '" + CEOShop + "'";
                    MySqlCommand command = new MySqlCommand(selectshop, conn);
                    command.ExecuteNonQuery();
                    MySqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        if (reader["ceoshop"].ToString() == CEOShop)
                        {
                            MessageBox.Show("이미 존재하는 종목입니다. 다른 종목을 입력하여 주십시오.");
                        }
                        if (reader["ceoid"].ToString() == CEOID)
                        {
                            MessageBox.Show("존재하는 아이디.");
                        }
                    }
                    else
                    {
                        // 회원가입의 조건 만족시
                        conn2.Open();
                        string sql = "insert into ceo(ceoid, ceoname, ceoshop) values('" + CEOID + "', '" + CEOName + "', '" + CEOShop + "')";
                        MySqlCommand command2 = new MySqlCommand(sql, conn2);
                        command2.ExecuteNonQuery();
                        MessageBox.Show("CEO 회원가입 되었습니다.");

                        Login showLogin = new Login();
                        this.Visible = false;             // 현재 창(Window)를 닫기
                        showLogin.ShowDialog();
                    }
                }
                catch (Exception)
                {
                    

                }
                finally
                {
                    conn.Close();
                    conn2.Close();

                }
            }
        }
    }
}
