﻿namespace FoodPlatform
{
    partial class CeoAdjust
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_MPF = new System.Windows.Forms.ComboBox();
            this.button_Mfix = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_MFprice = new System.Windows.Forms.TextBox();
            this.textBox_MFTrace = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_Madd = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_MAprice = new System.Windows.Forms.TextBox();
            this.textBox_MAname = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.comboBox_MD = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_MDTrace = new System.Windows.Forms.TextBox();
            this.button_Mdelete = new System.Windows.Forms.Button();
            this.label_id = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.button_out = new System.Windows.Forms.Button();
            this.label_shopname = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(31, 60);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(371, 378);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox_MPF);
            this.tabPage1.Controls.Add(this.button_Mfix);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox_MFprice);
            this.tabPage1.Controls.Add(this.textBox_MFTrace);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(363, 346);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "가격 수정";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_MPF
            // 
            this.comboBox_MPF.FormattingEnabled = true;
            this.comboBox_MPF.Location = new System.Drawing.Point(164, 73);
            this.comboBox_MPF.Name = "comboBox_MPF";
            this.comboBox_MPF.Size = new System.Drawing.Size(140, 26);
            this.comboBox_MPF.TabIndex = 19;
            this.comboBox_MPF.SelectedIndexChanged += new System.EventHandler(this.comboBox_MPF_SelectedIndexChanged);
            // 
            // button_Mfix
            // 
            this.button_Mfix.Location = new System.Drawing.Point(196, 255);
            this.button_Mfix.Name = "button_Mfix";
            this.button_Mfix.Size = new System.Drawing.Size(108, 41);
            this.button_Mfix.TabIndex = 18;
            this.button_Mfix.Text = "수정";
            this.button_Mfix.UseVisualStyleBackColor = true;
            this.button_Mfix.Click += new System.EventHandler(this.button_Mfix_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 17;
            this.label2.Text = "가격";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 16;
            this.label1.Text = "상품이름";
            // 
            // textBox_MFprice
            // 
            this.textBox_MFprice.Location = new System.Drawing.Point(164, 187);
            this.textBox_MFprice.Name = "textBox_MFprice";
            this.textBox_MFprice.Size = new System.Drawing.Size(140, 28);
            this.textBox_MFprice.TabIndex = 15;
            // 
            // textBox_MFTrace
            // 
            this.textBox_MFTrace.Location = new System.Drawing.Point(164, 133);
            this.textBox_MFTrace.Name = "textBox_MFTrace";
            this.textBox_MFTrace.ReadOnly = true;
            this.textBox_MFTrace.Size = new System.Drawing.Size(140, 28);
            this.textBox_MFTrace.TabIndex = 14;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_Madd);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.textBox_MAprice);
            this.tabPage2.Controls.Add(this.textBox_MAname);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(363, 346);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "메뉴 추가";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_Madd
            // 
            this.button_Madd.Location = new System.Drawing.Point(191, 218);
            this.button_Madd.Name = "button_Madd";
            this.button_Madd.Size = new System.Drawing.Size(108, 41);
            this.button_Madd.TabIndex = 17;
            this.button_Madd.Text = "메뉴추가";
            this.button_Madd.UseVisualStyleBackColor = true;
            this.button_Madd.Click += new System.EventHandler(this.button_Madd_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(67, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 18);
            this.label5.TabIndex = 16;
            this.label5.Text = "가격";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 15;
            this.label6.Text = "상품이름";
            // 
            // textBox_MAprice
            // 
            this.textBox_MAprice.Location = new System.Drawing.Point(159, 150);
            this.textBox_MAprice.Name = "textBox_MAprice";
            this.textBox_MAprice.Size = new System.Drawing.Size(140, 28);
            this.textBox_MAprice.TabIndex = 14;
            // 
            // textBox_MAname
            // 
            this.textBox_MAname.Location = new System.Drawing.Point(159, 96);
            this.textBox_MAname.Name = "textBox_MAname";
            this.textBox_MAname.Size = new System.Drawing.Size(140, 28);
            this.textBox_MAname.TabIndex = 13;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.comboBox_MD);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.textBox_MDTrace);
            this.tabPage3.Controls.Add(this.button_Mdelete);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(363, 346);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "메뉴 삭제";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // comboBox_MD
            // 
            this.comboBox_MD.FormattingEnabled = true;
            this.comboBox_MD.Location = new System.Drawing.Point(169, 81);
            this.comboBox_MD.Name = "comboBox_MD";
            this.comboBox_MD.Size = new System.Drawing.Size(140, 26);
            this.comboBox_MD.TabIndex = 22;
            this.comboBox_MD.SelectedIndexChanged += new System.EventHandler(this.comboBox_MD_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 21;
            this.label3.Text = "상품이름";
            // 
            // textBox_MDTrace
            // 
            this.textBox_MDTrace.Location = new System.Drawing.Point(169, 141);
            this.textBox_MDTrace.Name = "textBox_MDTrace";
            this.textBox_MDTrace.ReadOnly = true;
            this.textBox_MDTrace.Size = new System.Drawing.Size(140, 28);
            this.textBox_MDTrace.TabIndex = 20;
            // 
            // button_Mdelete
            // 
            this.button_Mdelete.Location = new System.Drawing.Point(201, 238);
            this.button_Mdelete.Name = "button_Mdelete";
            this.button_Mdelete.Size = new System.Drawing.Size(108, 41);
            this.button_Mdelete.TabIndex = 17;
            this.button_Mdelete.Text = "메뉴 삭제";
            this.button_Mdelete.UseVisualStyleBackColor = true;
            this.button_Mdelete.Click += new System.EventHandler(this.button_Mdelete_Click);
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Location = new System.Drawing.Point(150, 22);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(62, 18);
            this.label_id.TabIndex = 9;
            this.label_id.Text = "아이디";
            this.label_id.Visible = false;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(258, 22);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(44, 18);
            this.label_name.TabIndex = 8;
            this.label_name.Text = "이름";
            this.label_name.Visible = false;
            // 
            // button_out
            // 
            this.button_out.Location = new System.Drawing.Point(2, 3);
            this.button_out.Name = "button_out";
            this.button_out.Size = new System.Drawing.Size(95, 37);
            this.button_out.TabIndex = 10;
            this.button_out.Text = "로그아웃";
            this.button_out.UseVisualStyleBackColor = true;
            this.button_out.Click += new System.EventHandler(this.button_out_Click);
            // 
            // label_shopname
            // 
            this.label_shopname.AutoSize = true;
            this.label_shopname.Location = new System.Drawing.Point(332, 22);
            this.label_shopname.Name = "label_shopname";
            this.label_shopname.Size = new System.Drawing.Size(80, 18);
            this.label_shopname.TabIndex = 11;
            this.label_shopname.Text = "가게이름";
            this.label_shopname.Visible = false;
            // 
            // CeoAdjust
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 450);
            this.Controls.Add(this.label_shopname);
            this.Controls.Add(this.button_out);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.tabControl1);
            this.Name = "CeoAdjust";
            this.Text = "CeoAdjust";
            this.Load += new System.EventHandler(this.CeoAdjust_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ComboBox comboBox_MPF;
        private System.Windows.Forms.Button button_Mfix;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_MFprice;
        private System.Windows.Forms.TextBox textBox_MFTrace;
        private System.Windows.Forms.Button button_Madd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_MAprice;
        private System.Windows.Forms.TextBox textBox_MAname;
        private System.Windows.Forms.ComboBox comboBox_MD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_MDTrace;
        private System.Windows.Forms.Button button_Mdelete;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button button_out;
        private System.Windows.Forms.Label label_shopname;
    }
}