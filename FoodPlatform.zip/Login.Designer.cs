﻿namespace FoodPlatform
{
    partial class Login
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.login_tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button_Join = new System.Windows.Forms.Button();
            this.button_Login = new System.Windows.Forms.Button();
            this.textBox_Passwd = new System.Windows.Forms.TextBox();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_ceologin = new System.Windows.Forms.Button();
            this.textBox_CEOname = new System.Windows.Forms.TextBox();
            this.textBox_CEOid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_ceotitle = new System.Windows.Forms.Label();
            this.login_tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // login_tab
            // 
            this.login_tab.Controls.Add(this.tabPage1);
            this.login_tab.Controls.Add(this.tabPage2);
            this.login_tab.Location = new System.Drawing.Point(12, 12);
            this.login_tab.Name = "login_tab";
            this.login_tab.SelectedIndex = 0;
            this.login_tab.Size = new System.Drawing.Size(776, 426);
            this.login_tab.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button_Join);
            this.tabPage1.Controls.Add(this.button_Login);
            this.tabPage1.Controls.Add(this.textBox_Passwd);
            this.tabPage1.Controls.Add(this.textBox_ID);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 394);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "회원";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button_Join
            // 
            this.button_Join.Location = new System.Drawing.Point(163, 286);
            this.button_Join.Name = "button_Join";
            this.button_Join.Size = new System.Drawing.Size(148, 71);
            this.button_Join.TabIndex = 13;
            this.button_Join.Text = "회원가입";
            this.button_Join.UseVisualStyleBackColor = true;
            this.button_Join.Click += new System.EventHandler(this.button_Join_Click_1);
            // 
            // button_Login
            // 
            this.button_Login.Location = new System.Drawing.Point(482, 286);
            this.button_Login.Name = "button_Login";
            this.button_Login.Size = new System.Drawing.Size(148, 71);
            this.button_Login.TabIndex = 12;
            this.button_Login.Text = "로그인";
            this.button_Login.UseVisualStyleBackColor = true;
            this.button_Login.Click += new System.EventHandler(this.button_Login_Click_1);
            // 
            // textBox_Passwd
            // 
            this.textBox_Passwd.Location = new System.Drawing.Point(410, 215);
            this.textBox_Passwd.Name = "textBox_Passwd";
            this.textBox_Passwd.Size = new System.Drawing.Size(100, 28);
            this.textBox_Passwd.TabIndex = 11;
            // 
            // textBox_ID
            // 
            this.textBox_ID.Location = new System.Drawing.Point(410, 139);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(100, 28);
            this.textBox_ID.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(246, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "비밀번호";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(246, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "아이디";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(331, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 18);
            this.label1.TabIndex = 7;
            this.label1.Text = "회원 로그인";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_ceologin);
            this.tabPage2.Controls.Add(this.textBox_CEOname);
            this.tabPage2.Controls.Add(this.textBox_CEOid);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label_ceotitle);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 394);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "CEO";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_ceologin
            // 
            this.button_ceologin.Location = new System.Drawing.Point(350, 280);
            this.button_ceologin.Name = "button_ceologin";
            this.button_ceologin.Size = new System.Drawing.Size(148, 71);
            this.button_ceologin.TabIndex = 19;
            this.button_ceologin.Text = "로그인";
            this.button_ceologin.UseVisualStyleBackColor = true;
            this.button_ceologin.Click += new System.EventHandler(this.button_ceologin_Click);
            // 
            // textBox_CEOname
            // 
            this.textBox_CEOname.Location = new System.Drawing.Point(398, 207);
            this.textBox_CEOname.Name = "textBox_CEOname";
            this.textBox_CEOname.Size = new System.Drawing.Size(100, 28);
            this.textBox_CEOname.TabIndex = 18;
            // 
            // textBox_CEOid
            // 
            this.textBox_CEOid.Location = new System.Drawing.Point(398, 131);
            this.textBox_CEOid.Name = "textBox_CEOid";
            this.textBox_CEOid.Size = new System.Drawing.Size(100, 28);
            this.textBox_CEOid.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(234, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 18);
            this.label4.TabIndex = 16;
            this.label4.Text = "이름";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(234, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 18);
            this.label5.TabIndex = 15;
            this.label5.Text = "아이디";
            // 
            // label_ceotitle
            // 
            this.label_ceotitle.AutoSize = true;
            this.label_ceotitle.Location = new System.Drawing.Point(309, 46);
            this.label_ceotitle.Name = "label_ceotitle";
            this.label_ceotitle.Size = new System.Drawing.Size(104, 18);
            this.label_ceotitle.TabIndex = 14;
            this.label_ceotitle.Text = "CEO 로그인";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.login_tab);
            this.Name = "Login";
            this.Text = "Form1";
            this.login_tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl login_tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button_Join;
        private System.Windows.Forms.Button button_Login;
        private System.Windows.Forms.TextBox textBox_Passwd;
        private System.Windows.Forms.TextBox textBox_ID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button_ceologin;
        private System.Windows.Forms.TextBox textBox_CEOname;
        private System.Windows.Forms.TextBox textBox_CEOid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_ceotitle;
    }
}

