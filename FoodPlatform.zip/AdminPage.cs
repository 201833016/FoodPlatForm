﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다

namespace FoodPlatform
{
    public partial class AdminPage : Form
    {
       
        public AdminPage()
        {
            InitializeComponent();
            checkcombo();

            shopcombo();
        }

        void shopcombo()
        {
            // 콤보박스에 가게 종류 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = " select distinct ceoshop from ceo";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                comboBox_shop1.Items.Clear();
                comboBox_shop2.Items.Clear();
                comboBox_shop3.Items.Clear();
                while (myreader.Read())
                {
                    string sshop = myreader.GetString("ceoshop");
                    comboBox_shop1.Items.Add(sshop);
                    comboBox_shop2.Items.Add(sshop);
                    comboBox_shop3.Items.Add(sshop);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }


        private void AdminPage_Load(object sender, EventArgs e)
        {
            check_product.Checked = false;
            check_shop.Checked = false;
            check_time.Checked = false;
        }


        void checkcombo()
        {
            // DB tb값 사용자 아이디 값 콤보박스에 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select id from user";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string sid = myreader.GetString("id");
                    comboBox_user.Items.Add(sid);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            // 주문 검색
            string productname = "";
            string shopname = "";
            string timename = "";

            if (check_product.Checked)
            {
                productname = "product";
            }
            if (check_shop.Checked)
            {
                shopname = "foodmesort";
            }
            if (check_time.Checked)
            {
                timename = "ymd";
            }

            string constring = "Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            
            if (check_product.Checked && check_shop.Checked == false && check_time.Checked == false)
            {
                // 제품명
                MySqlCommand cmdDatabase = new MySqlCommand("select orderlog." + productname + " as 제품명 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
            else if (check_product.Checked == false && check_shop.Checked && check_time.Checked == false)
            {
                // 가게
                MySqlCommand cmdDatabase = new MySqlCommand("select foodmenu." + shopname + " as 가게 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
            else if (check_product.Checked == false && check_shop.Checked == false && check_time.Checked)
            {
                //주문시간
                MySqlCommand cmdDatabase = new MySqlCommand("select orderlog." + timename + " as 주문시간 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
            else if (check_product.Checked && check_shop.Checked == false && check_time.Checked)
            {
                // 제품명, 주문시간
                MySqlCommand cmdDatabase = new MySqlCommand("select orderlog." + productname + " as 제품명, orderlog." + timename + " as 주문시간 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
            else if (check_product.Checked == false && check_shop.Checked && check_time.Checked)
            {
                // 가게, 주문시간
                MySqlCommand cmdDatabase = new MySqlCommand("select foodmenu." + shopname + " as 가게 , orderlog." + timename + " as 주문시간 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
            else if (check_product.Checked && check_shop.Checked && check_time.Checked == false)
            {
                // 제품명, 가게 선택
                MySqlCommand cmdDatabase = new MySqlCommand("select orderlog." + productname + " as 제품명, foodmenu." + shopname + " as 가게 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
            else if (check_product.Checked && check_shop.Checked && check_time.Checked)
            {
                //3개 다 체크되었을경우
                MySqlCommand cmdDatabase = new MySqlCommand("select orderlog." + productname + " as 제품명, foodmenu." + shopname + " as 가게 , orderlog." + timename + " as 주문시간 from user, orderlog, foodmenu where user.id = '" + comboBox_user.Text + "' and user.id = orderlog.user and orderlog.product = foodmenu.foodname;", conDatabase);
                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDatabase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource dbSouce = new BindingSource();

                    dbSouce.DataSource = dbdataset;
                    dataGridView2.DataSource = dbSouce;
                    sda.Update(dbdataset);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                }
            }
        }

       

        private void button_out_Click(object sender, EventArgs e)
        {
            // 로그아웃 버튼
            Login showlogin = new Login();
            this.Visible = false;             // 현재 창(Window)를 닫기
            showlogin.ShowDialog();
        }

        private void comboBox_shop1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodmesort ='" + comboBox_shop1.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();

                comboBox_MenuCombo.Items.Clear();
                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    comboBox_MenuCombo.Items.Add(sname);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox_MenuCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='" + comboBox_MenuCombo.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();


                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    string sprice = myreader.GetString("foodprice");
                    this.textBox_MenuCB.Text = sname;
                    this.textBox_MenuPriceFix.Text = sprice;


                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_Mfix_Click(object sender, EventArgs e)
        {
            // 가격 수정
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "update foodmenu set foodprice = '" + textBox_MenuPriceFix.Text + "' where foodname = '" + textBox_MenuCB.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_MenuCB.Text + "가격을 수정하였습니다.");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            reload();
        }


        void reload()
        {
            // 다음 행동을 위한 빈칸으로 처리
            shopcombo();

            textBox_MenuCB.Text = "";
            textBox_MenuDelete.Text = "";
            textBox_MenuPriceFix.Text = "";
            textBox_MenuAddPrice.Text = "";
            textBox_MenuAdd.Text = "";
            comboBox_MenuCombo.Text = "";
            comboBox_Menucombo2.Text = "";
            comboBox_shop1.Text = "";
            comboBox_shop2.Text = "";
            comboBox_shop3.Text = "";

        }

        private void button_MenuAdd_Click(object sender, EventArgs e)
        {
            // 메뉴 추가 버튼 클릭시
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "insert into foodmenu values('" + textBox_MenuAdd.Text + "', " + textBox_MenuAddPrice.Text + ", '" + comboBox_shop2.Text + "')";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_MenuAdd.Text + "메뉴를 추가하였습니다.");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            reload();
        }

        private void comboBox_shop3_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodmesort ='" + comboBox_shop3.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();

                comboBox_Menucombo2.Items.Clear();
                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    comboBox_Menucombo2.Items.Add(sname);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_Mdelete_Click(object sender, EventArgs e)
        {
            // 메뉴 삭제 버튼 클릭시
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "delete from foodmenu where foodname = '" + textBox_MenuDelete.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_MenuDelete.Text + "메뉴를 삭제하였습니다.");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            reload();
        }

        private void comboBox_Menucombo2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='" + comboBox_Menucombo2.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();

                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    this.textBox_MenuDelete.Text = sname;



                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }
    }
}
