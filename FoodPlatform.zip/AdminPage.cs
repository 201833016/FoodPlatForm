﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다

namespace FoodPlatform
{
    public partial class AdminPage : Form
    {
       
        public AdminPage()
        {
            InitializeComponent();
            chickencombo();
            cafecombo();
        }

        private void comboBox_menu_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='"+ comboBox_menu.Text +"'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    string sprice = myreader.GetString("foodprice");
                    this.textBox_chicken.Text = sname;
                    this.textBox_chickenprice.Text = sprice;
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }
        private void comboBox_menu2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 콤보박스 선택시 tb에 연동된 값 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodname ='" + comboBox_menu2.Text + "'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string sname = myreader.GetString("foodname");
                    string sprice = myreader.GetString("foodprice");
                    this.textBox_coffee.Text = sname;
                    this.textBox_coffeeprice.Text = sprice;
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        void chickencombo()
        {
            // DB tb값 치킨 값 콤보박스에 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodmesort = '치킨'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string smenu = myreader.GetString("foodname");
                    comboBox_menu.Items.Add(smenu);
                }
                command.ExecuteNonQuery();
               
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        void cafecombo()
        {
            // DB tb값 카페 값 콤보박스에 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlDataReader myreader;
            try
            {
                conn.Open();
                string sql = "select * from foodmenu where foodmesort = '카페'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                myreader = command.ExecuteReader();
                while (myreader.Read())
                {
                    string smenu = myreader.GetString("foodname");
                    comboBox_menu2.Items.Add(smenu);
                }
                command.ExecuteNonQuery();

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        private void button_fix_Click(object sender, EventArgs e)
        {
            // 가격 수정
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            try
            {
                conn.Open();
                string sql = "update foodmenu set foodprice = '"+textBox_chickenprice.Text+"' where foodname = '"+textBox_chicken.Text+"'";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox_chicken.Text+"가격을 수정하였습니다.", "치킨");
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
        }

        

        private void button1_Click_1(object sender, EventArgs e)
        {
            string constring = "Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand("select no,user,product,ymd from foodplatform.orderlog;", conDatabase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDatabase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource dbSouce = new BindingSource();

                dbSouce.DataSource = dbdataset;
                dataGridView1.DataSource = dbSouce;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

 
        // 수정 버튼누르면, 수정되게,
        // 외래키 연결해서 연결되게
    }
}
