﻿namespace FoodPlatform
{
    partial class BasketPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_grade = new System.Windows.Forms.Label();
            this.label_id = new System.Windows.Forms.Label();
            this.label_money = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.button_Basketcheck = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button_BasketAllDel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label_grade
            // 
            this.label_grade.AutoSize = true;
            this.label_grade.Location = new System.Drawing.Point(514, 26);
            this.label_grade.Name = "label_grade";
            this.label_grade.Size = new System.Drawing.Size(44, 18);
            this.label_grade.TabIndex = 47;
            this.label_grade.Text = "등급";
            this.label_grade.Visible = false;
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Location = new System.Drawing.Point(407, 26);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(62, 18);
            this.label_id.TabIndex = 46;
            this.label_id.Text = "아이디";
            this.label_id.Visible = false;
            // 
            // label_money
            // 
            this.label_money.AutoSize = true;
            this.label_money.Location = new System.Drawing.Point(690, 26);
            this.label_money.Name = "label_money";
            this.label_money.Size = new System.Drawing.Size(44, 18);
            this.label_money.TabIndex = 45;
            this.label_money.Text = "잔금";
            this.label_money.Visible = false;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(594, 26);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(44, 18);
            this.label_name.TabIndex = 44;
            this.label_name.Text = "이름";
            // 
            // button_Basketcheck
            // 
            this.button_Basketcheck.Location = new System.Drawing.Point(41, 370);
            this.button_Basketcheck.Name = "button_Basketcheck";
            this.button_Basketcheck.Size = new System.Drawing.Size(267, 47);
            this.button_Basketcheck.TabIndex = 50;
            this.button_Basketcheck.Text = "조회";
            this.button_Basketcheck.UseVisualStyleBackColor = true;
            this.button_Basketcheck.Click += new System.EventHandler(this.button_Basketcheck_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(41, 91);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(636, 253);
            this.dataGridView1.TabIndex = 49;
            // 
            // button_BasketAllDel
            // 
            this.button_BasketAllDel.Location = new System.Drawing.Point(410, 370);
            this.button_BasketAllDel.Name = "button_BasketAllDel";
            this.button_BasketAllDel.Size = new System.Drawing.Size(267, 47);
            this.button_BasketAllDel.TabIndex = 51;
            this.button_BasketAllDel.Text = "장바구니 전부 삭제";
            this.button_BasketAllDel.UseVisualStyleBackColor = true;
            this.button_BasketAllDel.Click += new System.EventHandler(this.button_BasketAllDel_Click);
            // 
            // BasketPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_BasketAllDel);
            this.Controls.Add(this.button_Basketcheck);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label_grade);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.label_money);
            this.Controls.Add(this.label_name);
            this.Name = "BasketPage";
            this.Text = "BasketPage";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_grade;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.Label label_money;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button button_Basketcheck;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button_BasketAllDel;
    }
}