﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다


namespace FoodPlatform
{
    public partial class charge : Form
    {
        public charge()
        {
            InitializeComponent();
            label_id.Text = DataManager.id;
            Userdata();
            coupon();
        }

        private void Userdata()
        {
            // 회원의 이름, 잔금, 등급 가져오기
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();
            MySqlConnection conn3 = dbconn.Connection();

            string name = "select name from user where id = '" + label_id.Text + "'";
            string money = "select money from user where id = '" + label_id.Text + "'";
            string grade = "select grade from user where id = '" + label_id.Text + "'";

            MySqlCommand cmd = new MySqlCommand(name);
            MySqlCommand cmd2 = new MySqlCommand(money);
            MySqlCommand cmd3 = new MySqlCommand(grade);
            cmd.Connection = conn;
            cmd2.Connection = conn2;
            cmd3.Connection = conn3;

            conn.Open();
            conn2.Open();
            conn3.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            MySqlDataReader reader2 = cmd2.ExecuteReader();
            MySqlDataReader reader3 = cmd3.ExecuteReader();
            try
            {
                while (reader.Read() && reader2.Read() && reader3.Read())
                {
                    label_name.Text = (reader.GetString(0) + "님");
                    label_money.Text = (reader2.GetString(0) + "원");
                    label_grade.Text = (reader3.GetString(0));
                }
            }
            catch
            {

            }
            finally
            {
                conn.Close();
                conn2.Close();
                conn3.Close();
            }
        }
        private void button_charge_Click(object sender, EventArgs e)
        {
            // 잔금 충전
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();

            if (textBox_charge.Text == "")
            {
                MessageBox.Show("충전할 금액을 입력하시오");
            }
            else
            {
                try
                {
                    conn.Open();
                    string sql = "update user set money= money +" + textBox_charge.Text + " where id='" + label_id.Text + "'";
                    MySqlCommand command = new MySqlCommand(sql, conn);
                    command.ExecuteNonQuery();
                    MessageBox.Show("충전 되었습니다.");
                    Userdata();

                }
                catch (Exception)
                {

                }
                finally
                {
                    conn.Close();
                }

            }
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            // 메인으로 버튼 클릭시
            Main showMain = new Main();
            this.Visible = false;             // 현재 창(Window)를 닫기
            showMain.ShowDialog();
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            // 주문내역 조회
            string constring = "Server=localhost;Database=foodplatform;Uid=root;Pwd=test1234";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand("select orderlog.product, orderlog.count, orderlog.ymd from user inner join orderlog on user.id = orderlog.user where user.id = '"+ label_id.Text + "'", conDatabase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDatabase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource dbSouce = new BindingSource();

                dbSouce.DataSource = dbdataset;
                dataGridView1.DataSource = dbSouce;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

        void coupon()
        {
            // 쿠폰 뽑기를 위한 처리
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();
            MySqlConnection conn3 = dbconn.Connection();

            string chicken = "select cpid from coupon where discount = 1000";
            string drink = "select cpid from coupon where discount = 3000";
            string source = "select cpid from coupon where discount = 5000";

            MySqlCommand cmd = new MySqlCommand(chicken);
            MySqlCommand cmd2 = new MySqlCommand(drink);
            MySqlCommand cmd3 = new MySqlCommand(source);
            cmd.Connection = conn;
            cmd2.Connection = conn2;
            cmd3.Connection = conn3;

            conn.Open();
            conn2.Open();
            conn3.Open();

            MySqlDataReader reader = cmd.ExecuteReader();
            MySqlDataReader reader2 = cmd2.ExecuteReader();
            MySqlDataReader reader3 = cmd3.ExecuteReader();
            try
            {
                while (reader.Read() && reader2.Read() && reader3.Read())
                {
                    label1.Text = (reader.GetString(0));
                    label2.Text = (reader2.GetString(0));
                    label3.Text = (reader3.GetString(0));
                }
            }
            catch
            {

            }
            finally
            {
                conn.Close();
                conn2.Close();
                conn3.Close();
            }
        }

        private void button_coupon_Click(object sender, EventArgs e)
        {
            // 뽑기 버튼 클릭시
            rando();
            int aaa = Convert.ToInt32(label4.Text);
            int cp = 0;
            if (aaa == 1)
            {
                label5.Text = label1.Text;
                label_cpname.Text = "1000원할인";
                cp = 1000;
                 
            }
            else if (aaa == 2)  
            {
                label5.Text = label2.Text;
                label_cpname.Text = "3000원할인";
                cp = 3000;
            }
            else if (aaa == 3)
            {
                label5.Text = label3.Text;
                label_cpname.Text = "5000원할인";
                cp = 5000;
            }

            label_discnt.Text = Convert.ToString(cp);
            int discount = Convert.ToInt32(label_discnt.Text);


            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();
            MySqlConnection conn2 = dbconn.Connection();

            conn.Open();
            string sql = "select userid from eventwin where userid = '" + label_id.Text + "'";
            try
            {
                conn2.Open();
                string sql2 = "insert into eventwin values('" + label_id.Text + "', '" + label5.Text + "', '" + label_grade.Text + "', " + discount + ", '" + label_cpname.Text + "')";

                MySqlCommand command = new MySqlCommand(sql, conn);
                MySqlCommand command2 = new MySqlCommand(sql2, conn2);
                command.ExecuteNonQuery();
                command2.ExecuteNonQuery();

                MessageBox.Show(label_cpname.Text + " 쿠폰을 받았습니다.");
                Userdata();
            }
            catch (Exception)
            {
                MessageBox.Show("이미 쿠폰을 가지고 있습니다.");
            }
            finally
            {
                conn.Close();
                conn2.Close();
            }


        }

        void rando()
        {
            // 랜덤으로 쿠폰3개중 1개 가져오기
            Random randomObj = new Random();

            List<int> list = new List<int>();

            int randomValue;

            for (int i = 0; i < 1; i++)
            {
                randomValue = randomObj.Next(1, 4);

                if (!list.Contains(randomValue))
                {
                    list.Add(randomValue);
                    label4.Text = randomValue.ToString();
                }

            }
        }

    }
}
