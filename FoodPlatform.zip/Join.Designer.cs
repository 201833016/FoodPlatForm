﻿namespace FoodPlatform
{
    partial class Join
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_out = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.button_Join = new System.Windows.Forms.Button();
            this.textBox_Passwd = new System.Windows.Forms.TextBox();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_CeoID = new System.Windows.Forms.TextBox();
            this.textBox_CeoName = new System.Windows.Forms.TextBox();
            this.textBox_CeoShop = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_CeoJoin = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_out
            // 
            this.button_out.Location = new System.Drawing.Point(1, -1);
            this.button_out.Name = "button_out";
            this.button_out.Size = new System.Drawing.Size(117, 44);
            this.button_out.TabIndex = 16;
            this.button_out.Text = "로그인 화면";
            this.button_out.UseVisualStyleBackColor = true;
            this.button_out.Click += new System.EventHandler(this.button_out_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 49);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 389);
            this.tabControl1.TabIndex = 32;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox_name);
            this.tabPage1.Controls.Add(this.label_name);
            this.tabPage1.Controls.Add(this.button_Join);
            this.tabPage1.Controls.Add(this.textBox_Passwd);
            this.tabPage1.Controls.Add(this.textBox_ID);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 357);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "회원 ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_CeoJoin);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.textBox_CeoShop);
            this.tabPage2.Controls.Add(this.textBox_CeoName);
            this.tabPage2.Controls.Add(this.textBox_CeoID);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 357);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "CEO";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(361, 222);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(127, 28);
            this.textBox_name.TabIndex = 39;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(207, 222);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(44, 18);
            this.label_name.TabIndex = 38;
            this.label_name.Text = "이름";
            // 
            // button_Join
            // 
            this.button_Join.Location = new System.Drawing.Point(444, 268);
            this.button_Join.Name = "button_Join";
            this.button_Join.Size = new System.Drawing.Size(118, 72);
            this.button_Join.TabIndex = 37;
            this.button_Join.Text = "회원가입";
            this.button_Join.UseVisualStyleBackColor = true;
            this.button_Join.Click += new System.EventHandler(this.button_Join_Click_1);
            // 
            // textBox_Passwd
            // 
            this.textBox_Passwd.Location = new System.Drawing.Point(361, 143);
            this.textBox_Passwd.Name = "textBox_Passwd";
            this.textBox_Passwd.Size = new System.Drawing.Size(127, 28);
            this.textBox_Passwd.TabIndex = 36;
            // 
            // textBox_ID
            // 
            this.textBox_ID.Location = new System.Drawing.Point(361, 73);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(127, 28);
            this.textBox_ID.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(207, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 34;
            this.label3.Text = "비밀번호";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 18);
            this.label2.TabIndex = 33;
            this.label2.Text = "아이디";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(305, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 32;
            this.label1.Text = "회원가입";
            // 
            // textBox_CeoID
            // 
            this.textBox_CeoID.Location = new System.Drawing.Point(274, 86);
            this.textBox_CeoID.Name = "textBox_CeoID";
            this.textBox_CeoID.Size = new System.Drawing.Size(166, 28);
            this.textBox_CeoID.TabIndex = 0;
            // 
            // textBox_CeoName
            // 
            this.textBox_CeoName.Location = new System.Drawing.Point(274, 151);
            this.textBox_CeoName.Name = "textBox_CeoName";
            this.textBox_CeoName.Size = new System.Drawing.Size(166, 28);
            this.textBox_CeoName.TabIndex = 1;
            // 
            // textBox_CeoShop
            // 
            this.textBox_CeoShop.Location = new System.Drawing.Point(274, 220);
            this.textBox_CeoShop.Name = "textBox_CeoShop";
            this.textBox_CeoShop.Size = new System.Drawing.Size(166, 28);
            this.textBox_CeoShop.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(287, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "CEO 회원가입";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "아이디";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(190, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "이름";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(190, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "종목";
            // 
            // button_CeoJoin
            // 
            this.button_CeoJoin.Location = new System.Drawing.Point(274, 279);
            this.button_CeoJoin.Name = "button_CeoJoin";
            this.button_CeoJoin.Size = new System.Drawing.Size(166, 49);
            this.button_CeoJoin.TabIndex = 7;
            this.button_CeoJoin.Text = "CEO 회원가입";
            this.button_CeoJoin.UseVisualStyleBackColor = true;
            this.button_CeoJoin.Click += new System.EventHandler(this.button_CeoJoin_Click);
            // 
            // Join
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button_out);
            this.Name = "Join";
            this.Text = "Join";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_out;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button button_Join;
        private System.Windows.Forms.TextBox textBox_Passwd;
        private System.Windows.Forms.TextBox textBox_ID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox_CeoShop;
        private System.Windows.Forms.TextBox textBox_CeoName;
        private System.Windows.Forms.TextBox textBox_CeoID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_CeoJoin;
    }
}