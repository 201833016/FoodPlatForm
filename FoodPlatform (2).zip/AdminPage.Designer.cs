﻿namespace FoodPlatform
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_menu = new System.Windows.Forms.ComboBox();
            this.button_fix = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_chickenprice = new System.Windows.Forms.TextBox();
            this.textBox_chicken = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboBox_menu2 = new System.Windows.Forms.ComboBox();
            this.button_fix2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_coffeeprice = new System.Windows.Forms.TextBox();
            this.textBox_coffee = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.check_time = new System.Windows.Forms.CheckBox();
            this.check_shop = new System.Windows.Forms.CheckBox();
            this.check_product = new System.Windows.Forms.CheckBox();
            this.button_check = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.comboBox_user = new System.Windows.Forms.ComboBox();
            this.button_addmenu = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_chicprice2 = new System.Windows.Forms.TextBox();
            this.textBox_chic2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button_addcoffee = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_coffprice2 = new System.Windows.Forms.TextBox();
            this.textBox_coff2 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(764, 426);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.button_addmenu);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBox_chicprice2);
            this.tabPage1.Controls.Add(this.textBox_chic2);
            this.tabPage1.Controls.Add(this.comboBox_menu);
            this.tabPage1.Controls.Add(this.button_fix);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox_chickenprice);
            this.tabPage1.Controls.Add(this.textBox_chicken);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(756, 394);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "치킨";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_menu
            // 
            this.comboBox_menu.FormattingEnabled = true;
            this.comboBox_menu.Location = new System.Drawing.Point(142, 77);
            this.comboBox_menu.Name = "comboBox_menu";
            this.comboBox_menu.Size = new System.Drawing.Size(140, 26);
            this.comboBox_menu.TabIndex = 7;
            this.comboBox_menu.SelectedIndexChanged += new System.EventHandler(this.comboBox_menu_SelectedIndexChanged);
            // 
            // button_fix
            // 
            this.button_fix.Location = new System.Drawing.Point(174, 259);
            this.button_fix.Name = "button_fix";
            this.button_fix.Size = new System.Drawing.Size(108, 41);
            this.button_fix.TabIndex = 5;
            this.button_fix.Text = "수정";
            this.button_fix.UseVisualStyleBackColor = true;
            this.button_fix.Click += new System.EventHandler(this.button_fix_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "가격";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "상품이름";
            // 
            // textBox_chickenprice
            // 
            this.textBox_chickenprice.Location = new System.Drawing.Point(142, 191);
            this.textBox_chickenprice.Name = "textBox_chickenprice";
            this.textBox_chickenprice.Size = new System.Drawing.Size(140, 28);
            this.textBox_chickenprice.TabIndex = 1;
            // 
            // textBox_chicken
            // 
            this.textBox_chicken.Location = new System.Drawing.Point(142, 137);
            this.textBox_chicken.Name = "textBox_chicken";
            this.textBox_chicken.ReadOnly = true;
            this.textBox_chicken.Size = new System.Drawing.Size(140, 28);
            this.textBox_chicken.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_addcoffee);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.textBox_coffprice2);
            this.tabPage2.Controls.Add(this.textBox_coff2);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.comboBox_menu2);
            this.tabPage2.Controls.Add(this.button_fix2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.textBox_coffeeprice);
            this.tabPage2.Controls.Add(this.textBox_coffee);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(756, 394);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "커피";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBox_menu2
            // 
            this.comboBox_menu2.FormattingEnabled = true;
            this.comboBox_menu2.Location = new System.Drawing.Point(140, 77);
            this.comboBox_menu2.Name = "comboBox_menu2";
            this.comboBox_menu2.Size = new System.Drawing.Size(144, 26);
            this.comboBox_menu2.TabIndex = 12;
            this.comboBox_menu2.SelectedIndexChanged += new System.EventHandler(this.comboBox_menu2_SelectedIndexChanged);
            // 
            // button_fix2
            // 
            this.button_fix2.Location = new System.Drawing.Point(176, 269);
            this.button_fix2.Name = "button_fix2";
            this.button_fix2.Size = new System.Drawing.Size(108, 41);
            this.button_fix2.TabIndex = 11;
            this.button_fix2.Text = "수정";
            this.button_fix2.UseVisualStyleBackColor = true;
            this.button_fix2.Click += new System.EventHandler(this.button_fix2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 10;
            this.label3.Text = "가격";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "상품이름";
            // 
            // textBox_coffeeprice
            // 
            this.textBox_coffeeprice.Location = new System.Drawing.Point(140, 206);
            this.textBox_coffeeprice.Name = "textBox_coffeeprice";
            this.textBox_coffeeprice.Size = new System.Drawing.Size(144, 28);
            this.textBox_coffeeprice.TabIndex = 8;
            // 
            // textBox_coffee
            // 
            this.textBox_coffee.Location = new System.Drawing.Point(140, 152);
            this.textBox_coffee.Name = "textBox_coffee";
            this.textBox_coffee.ReadOnly = true;
            this.textBox_coffee.Size = new System.Drawing.Size(144, 28);
            this.textBox_coffee.TabIndex = 7;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.check_time);
            this.tabPage4.Controls.Add(this.check_shop);
            this.tabPage4.Controls.Add(this.check_product);
            this.tabPage4.Controls.Add(this.button_check);
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Controls.Add(this.comboBox_user);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(756, 394);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "주문 검색";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // check_time
            // 
            this.check_time.AutoSize = true;
            this.check_time.Location = new System.Drawing.Point(396, 24);
            this.check_time.Name = "check_time";
            this.check_time.Size = new System.Drawing.Size(106, 22);
            this.check_time.TabIndex = 8;
            this.check_time.Text = "주문시간";
            this.check_time.UseVisualStyleBackColor = true;
            // 
            // check_shop
            // 
            this.check_shop.AutoSize = true;
            this.check_shop.Location = new System.Drawing.Point(306, 24);
            this.check_shop.Name = "check_shop";
            this.check_shop.Size = new System.Drawing.Size(70, 22);
            this.check_shop.TabIndex = 7;
            this.check_shop.Text = "가게";
            this.check_shop.UseVisualStyleBackColor = true;
            // 
            // check_product
            // 
            this.check_product.AutoSize = true;
            this.check_product.Location = new System.Drawing.Point(194, 24);
            this.check_product.Name = "check_product";
            this.check_product.Size = new System.Drawing.Size(88, 22);
            this.check_product.TabIndex = 6;
            this.check_product.Text = "제품명";
            this.check_product.UseVisualStyleBackColor = true;
            // 
            // button_check
            // 
            this.button_check.Location = new System.Drawing.Point(587, 275);
            this.button_check.Name = "button_check";
            this.button_check.Size = new System.Drawing.Size(132, 65);
            this.button_check.TabIndex = 5;
            this.button_check.Text = "조회";
            this.button_check.UseVisualStyleBackColor = true;
            this.button_check.Click += new System.EventHandler(this.button_check_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 97);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 30;
            this.dataGridView2.Size = new System.Drawing.Size(564, 263);
            this.dataGridView2.TabIndex = 4;
            // 
            // comboBox_user
            // 
            this.comboBox_user.FormattingEnabled = true;
            this.comboBox_user.Location = new System.Drawing.Point(22, 22);
            this.comboBox_user.Name = "comboBox_user";
            this.comboBox_user.Size = new System.Drawing.Size(121, 26);
            this.comboBox_user.TabIndex = 3;
            // 
            // button_addmenu
            // 
            this.button_addmenu.Location = new System.Drawing.Point(554, 259);
            this.button_addmenu.Name = "button_addmenu";
            this.button_addmenu.Size = new System.Drawing.Size(108, 41);
            this.button_addmenu.TabIndex = 12;
            this.button_addmenu.Text = "메뉴추가";
            this.button_addmenu.UseVisualStyleBackColor = true;
            this.button_addmenu.Click += new System.EventHandler(this.button_addmenu_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(430, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "가격";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(408, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "상품이름";
            // 
            // textBox_chicprice2
            // 
            this.textBox_chicprice2.Location = new System.Drawing.Point(522, 191);
            this.textBox_chicprice2.Name = "textBox_chicprice2";
            this.textBox_chicprice2.Size = new System.Drawing.Size(140, 28);
            this.textBox_chicprice2.TabIndex = 9;
            // 
            // textBox_chic2
            // 
            this.textBox_chic2.Location = new System.Drawing.Point(522, 137);
            this.textBox_chic2.Name = "textBox_chic2";
            this.textBox_chic2.Size = new System.Drawing.Size(140, 28);
            this.textBox_chic2.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(139, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "가격수정";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(519, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "메뉴추가";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(553, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 18);
            this.label9.TabIndex = 16;
            this.label9.Text = "메뉴추가";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(173, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 18);
            this.label10.TabIndex = 15;
            this.label10.Text = "가격수정";
            // 
            // button_addcoffee
            // 
            this.button_addcoffee.Location = new System.Drawing.Point(542, 271);
            this.button_addcoffee.Name = "button_addcoffee";
            this.button_addcoffee.Size = new System.Drawing.Size(108, 41);
            this.button_addcoffee.TabIndex = 21;
            this.button_addcoffee.Text = "메뉴추가";
            this.button_addcoffee.UseVisualStyleBackColor = true;
            this.button_addcoffee.Click += new System.EventHandler(this.button_addcoffee_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(418, 203);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 18);
            this.label11.TabIndex = 20;
            this.label11.Text = "가격";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(396, 149);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 18);
            this.label12.TabIndex = 19;
            this.label12.Text = "상품이름";
            // 
            // textBox_coffprice2
            // 
            this.textBox_coffprice2.Location = new System.Drawing.Point(510, 203);
            this.textBox_coffprice2.Name = "textBox_coffprice2";
            this.textBox_coffprice2.Size = new System.Drawing.Size(140, 28);
            this.textBox_coffprice2.TabIndex = 18;
            // 
            // textBox_coff2
            // 
            this.textBox_coff2.Location = new System.Drawing.Point(510, 149);
            this.textBox_coff2.Name = "textBox_coff2";
            this.textBox_coff2.Size = new System.Drawing.Size(140, 28);
            this.textBox_coff2.TabIndex = 17;
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminPage";
            this.Text = "AdminPage";
            this.Load += new System.EventHandler(this.AdminPage_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button_fix;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_chickenprice;
        private System.Windows.Forms.TextBox textBox_chicken;
        private System.Windows.Forms.ComboBox comboBox_menu2;
        private System.Windows.Forms.Button button_fix2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_coffeeprice;
        private System.Windows.Forms.TextBox textBox_coffee;
        private System.Windows.Forms.ComboBox comboBox_menu;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox comboBox_user;
        private System.Windows.Forms.Button button_check;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.CheckBox check_time;
        private System.Windows.Forms.CheckBox check_shop;
        private System.Windows.Forms.CheckBox check_product;
        private System.Windows.Forms.Button button_addmenu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_chicprice2;
        private System.Windows.Forms.TextBox textBox_chic2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_addcoffee;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_coffprice2;
        private System.Windows.Forms.TextBox textBox_coff2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}