﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;  //참조로 추가한다


namespace FoodPlatform
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
        }
        private void button_Join_Click(object sender, EventArgs e)
        {
            //회원가입
            Join showJoin = new Join();         // 추후 관리자 페이지 생성후, 변경예정
            this.Visible = false;             // 현재 창(Window)를 닫기
            showJoin.ShowDialog();
        }

        private void button_Login_Click(object sender, EventArgs e)
        {
            // 로그인
            DBconn dbconn = new DBconn();
            MySqlConnection conn = dbconn.Connection();

            string LoginIdText = textBox_ID.Text;
            string LoginPWDText = textBox_Passwd.Text;

            if (LoginIdText.Trim() == "")
            {
                MessageBox.Show("아이디를 입력하시오");
            }
            else if (LoginPWDText.Trim() == "")
            {
                MessageBox.Show("비밀번호를 입력하시오");
            }
            else
            {
                if (LoginIdText == "admin" && LoginPWDText == "1234")
                {
                    // 관리자 코드 입력시
                    AdminPage showAdmin = new AdminPage();        
                    this.Visible = false;             // 현재 창(Window)를 닫기
                    showAdmin.ShowDialog();
                }
                else
                {
                    
                    try
                    {
                        // DB에 존재하는 값으로 로그인 시
                        conn.Open();
                        string sql = "select * from user where id ='" + LoginIdText + "'and password = '"+ LoginPWDText +"';";
                        MySqlCommand command = new MySqlCommand(sql, conn);
                        command.ExecuteNonQuery();
                        MySqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            if (reader["id"].ToString() == LoginIdText && reader["password"].ToString() == LoginPWDText)
                            {
                                DataManager.id = reader["id"].ToString();
                                MessageBox.Show("환영합니다");


                                Main showMain = new Main();       
                                this.Visible = false;             // 현재 창(Window)를 닫기
                                showMain.ShowDialog();
                            }
                            else if (reader["id"].ToString() == LoginIdText)
                            {
                                MessageBox.Show("패스워드가 일치하지 않습니다.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("존재하지 않는 회원입니다.");
                            //ceo_login();
                        }

                    }
                    catch (Exception)
                    {
                        
                    }
                    finally
                    {
                        conn.Close();
                    }
                    


                }
            }


        }

        void ceo_login()
        {
            DBconn dbconn = new DBconn();
            MySqlConnection conn2 = dbconn.Connection();
            try
            {
                // ceo 로그인
                conn2.Open();
                string sql2 = "select * from ceo where ceoid ='" + textBox_ID.Text + "';";
                MySqlCommand command2 = new MySqlCommand(sql2, conn2);
                command2.ExecuteNonQuery();
                MySqlDataReader reader2 = command2.ExecuteReader();
                if (reader2.Read())
                {
                    if (reader2["id"].ToString() == textBox_ID.Text)
                    {
                        DataManager.id = reader2["id"].ToString();
                        MessageBox.Show("사장님 환영합니다");
                    }
                }
                else
                {
                    MessageBox.Show("존재하지 않는 회원입니다.");
                }

            }
            catch (Exception)
            {

            }
            finally
            {
                conn2.Close();
            }
        }
    }
}
